<?php

class CustomerVIPGroup extends ObjectModel
{

	/** @var string Name */

	public $id_ns_vipgroup;	

	public $id_group;	

	/** @var string Name */

	public $id_customer;	

    /**

     * @see ObjectModel::$definition

     */

    public static $definition = array(
        'table' => 'ns_vipgroup',
        'primary' => 'id_ns_vipgroup',
        'multilang' => FALSE,
        'fields' => array(			
            'id_group' =>array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),				
			'id_customer'=>array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
        ),
    );

	

    public static function loadByIdCustomer($id_customer){

        $result = Db::getInstance()->getRow('
            SELECT *
            FROM `'._DB_PREFIX_.'ns_vipgroup` banner
            WHERE banner.`id_customer` = '.(int)$id_customer

        );

        

        return (new CustomerVIPGroup($result['id_ns_vipgroup'])) ;

    }
	

	

	public function getAllBanners()

	{

	    

	    $id_lang = (int)Context::getContext()->language->id; 

		

		$sql='SELECT  d.`id_ns_vipgroup` AS `id`, d.`id_group` AS id_group, d.`id_customer` AS `id_customer`,gl.`name` AS name ,
  		        CONCAT(c.`firstname` , "  ", c.`lastname`)  as  customerName
		         FROM `'._DB_PREFIX_.'ns_vipgroup`  d
				 LEFT JOIN `'._DB_PREFIX_.'group_lang`  gl  ON gl.`id_group`=d.`id_group`  AND gl.`id_lang`='.(int)$id_lang.'
				 LEFT JOIN `'._DB_PREFIX_.'customer`  c  ON c.`id_customer`=d.`id_customer`  ';			

		$orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);		



		return $orders;

		

	}	

		
	

	public  function getCustomerVIPGroupDetails(){

	$id_lang=(int)Context::getContext()->language->id; 

	if(Tools::getValue('id')){

	$id_banner=Tools::getValue('id');	

	$sql = 'SELECT  * FROM `'._DB_PREFIX_.'ns_vipgroup` q    

	        WHERE  q.`id_ns_vipgroup`='.$id_banner;	

    $results = Db::getInstance()->ExecuteS($sql);   

	return $results;	

	}	

	}	

	    
		
    
 

}



