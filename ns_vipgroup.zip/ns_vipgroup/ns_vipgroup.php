<?php
if (!defined('_PS_VERSION_')){
  exit;
 } 
 
require_once(dirname(__FILE__) . '/classes/CustomerVIPGroup.php');  


class ns_vipgroup  extends Module
  
{ 
  
  public function __construct()
  {
    $this->name = 'ns_vipgroup';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'NdiagaSoft';
    $this->need_instance = 0;
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' =>_PS_VERSION_);
    $this->bootstrap = true;
 
    parent::__construct();
 
    $this->displayName = $this->l('NS  Customer VIP  Group');
    $this->description = $this->l('Change customer group based on amount spent.');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); 
    
  }
  
  
  
  public function install()
{
  if (Shop::isFeatureActive())
    Shop::setContext(Shop::CONTEXT_ALL);
	$sql = array();
        
		
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ns_vipgroup` (
                  `id_ns_vipgroup` int(10) unsigned NOT NULL AUTO_INCREMENT,				  
                   `id_group` int(10)  NOT NULL,				  
				  `id_customer` int(10) NOT NULL,                  				  
                  PRIMARY KEY (`id_ns_vipgroup`),
				  UNIQUE  `CG_ID_UNIQ` (  `id_customer` )
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8'; 		
	
	
 
  if (!parent::install() ||    
	!$this->registerHook('OrderConfirmation')||	
    !$this->registerHook('DisplayOrderConfirmation')||
    !$this->registerHook('displayFooterProduct')||	
    !$this->registerHook('displayBanner')||		
    !$this->runSql($sql)
  )
    return false;
 
  return true;
}
       public function uninstall()
    {
        $sql = array();	
        
		$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'ns_vipgroup`';
		
		if (!parent::uninstall()||
		    !$this->runSql($sql)	
           )
                return false;
           $this->emptyUploads();
		   
           return true;
    }
	
	
   public function runSql($sql) {
        foreach ($sql as $s) {
			if (!Db::getInstance()->Execute($s)){
				return FALSE;
			}
        }
        
        return TRUE;
    }	
  
  
        public function getContent()
    {
          
		  
		  $output=$this->addMenu();
		  	
		  
	   if (Tools::isSubmit('submit'.$this->name))
      {
        $id_vip =(int)Tools::getValue('id_group');
		$max_order_amount =(int)Tools::getValue('max_order_amount');
		$min_order_period=(int)Tools::getValue('min_order_period');
		
        if (Tools::getValue('id_group') =='' && Tools::getValue('max_order_amount')=='')
            $output .= $this->displayError($this->l('Invalid Configuration value'));
        else
        {	
	
	         Configuration::updateValue('ID_VIP_GROUP', $id_vip);
			 Configuration::updateValue('MAX_ORDER_AMOUNT', $max_order_amount);
			 Configuration::updateValue('MIN_ORDER_PERIODE', $min_order_period);
			 
            $output.= $this->displayConfirmation($this->l('Settings updated'));
        }
		
		 
      } 
	  
      if(Tools::isSubmit('viewVIPLIST')) {
		  
		  $output.='</br>'.$this->renderLogoList();
	  }
	  
	  else{
		  
		  $output.='<br/>'.$this->displayForm();
		  
	  }
		  
		  
		
		
	      
		  	   
		   
		   
		   
      	
            return $output;
			
			
    }  
	
	
	
	public function addMenu(){

	$button= '<div class="panel">';
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewHome&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
	<button class="btn btn-default"><i class="icon-wrench"></i> '.$this->l('Home').'</button>
	</a>';
	
	$button .= '<a href="'.$this->context->link->getAdminLink('AdminModules', false).'&viewVIPLIST&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules').'">
	<button class="btn btn-default">'.$this->l('VIP  List').'</button>
	</a>';
	
	$button .='</div>';



	return $button;

	}   
	
	
	
   /*list of logos*/   
   	
      	public function renderLogoList()
	{
		$fields_list = array(
		
		   'id' => array(
				'title' => $this->l('ID'),
				'search' => false,
			),
			'id_group' => array(
				'title' => $this->l('ID Group'),
				'search' => false,
			),	
            'name' => array(
				'title' => $this->l('Group Name'),
				'search' => false,
			),								
					
			'customerName' => array(
				'title' => $this->l('Customer'),
				'search' => false,
			)
		);

		if (!Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE'))
			unset($fields_list['shop_name']);
		$helper_list = New HelperList();
		$helper_list->module = $this;
		$helper_list->title = $this->l('Customer VIP List ');
		$helper_list->shopLinkType = '';
		$helper_list->no_link = true;
		$helper_list->show_toolbar = true;
		$helper_list->simple_header = false;
		$helper_list->identifier = 'id';
		$helper_list->table = 'ns_vipgroup';
		$helper_list->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name;
		$helper_list->token = Tools::getAdminTokenLite('AdminModules');
		$helper_list->actions = array('view','delete');
		$helper_list->bulk_actions = array(
			'select' => array(
				'text' => $this->l('Change order status'),
				'icon' => 'icon-refresh',				
			)
		); 		

		/*This is needed for displayEnableLink to avoid code duplication*/
		$this->_helperlist = $helper_list;

		/* Retrieve list data */
		$order=new CustomerVIPGroup();
		$orders=$order->getAllBanners();
		$helper_list->listTotal = count($order->getAllBanners());

		/* Paginate the result */
		$page = ($page = Tools::getValue('submitFilter'.$helper_list->table)) ? $page : 1;
		$pagination = ($pagination = Tools::getValue($helper_list->table.'_pagination')) ? $pagination : 50;
		$orders = $this->paginateOrderProducts($orders, $page, $pagination);

		return $helper_list->generateList($orders, $fields_list);
		
	}
   
   
   
  
   public function paginateOrderProducts($orders, $page = 1, $pagination = 50)
	{
		if(count($orders) > $pagination)
			$orders= array_slice($orders, $pagination * ($page - 1), $pagination);

		return $orders;
	}   
	
	
	public function hookdisplayBanner($params)
	{
		 return '';
		
	}	
	
   
   public function displayForm()
  {
    // Get default language
    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	$id_shop=Context::getContext()->shop->id;;
	$id_lang=(int)Context::getContext()->language->id; 
    $Groups=Group::getGroups((int)$id_lang, (int)$id_shop);
	
	
    // Init Fields form array
    $fields_form[0]['form'] = array(
        'legend' => array(
            'title' => $this->l('VIP Group'),
			'icon' => 'icon-cogs'
        ),
            'input' => array(
            array(
                        'col' => 3,
                        'type' => 'text',                        
                        'desc' => $this->l('Enter your maxim order amount'),
                        'name' => 'max_order_amount',
                        'label' => $this->l(' Amount  to consider  a customer to VIP'),
                    ),
            array(
                        'col' => 3,
                        'type' => 'text',                        
                        'desc' => $this->l('Enter the minimum  order period .Ex: 12  for one year'),
                        'name' => 'min_order_period',
                        'label' => $this->l('The  number  of months'),
                    ),							
			array(
					'type' => 'select',
					'label' => $this->l('Select a Customer groups'),
					'name' => 'id_group',
					
					'options' => array(
						'query' =>$Groups,
						'id' => 'id_group',
						'name' => 'name'
						
					),
					'desc' => $this->l('Select a group you wish to consider the VIP Group.')
                      ),
					  
			 

      					  
        ),
        'submit' => array(
            'title' => $this->l('Save'),           
        )
    );
     
    $helper = new HelperForm();
     
    // Module, token and currentIndex
    $helper->module = $this;
    $helper->name_controller = $this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
     
    // Language
    $helper->default_form_language = $default_lang;
    $helper->allow_employee_form_lang = $default_lang;
     
    // Title and toolbar
    $helper->title = $this->displayName;
    $helper->show_toolbar = true;        // false -> remove toolbar
    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
    $helper->submit_action ='submit'.$this->name;
    $helper->toolbar_btn = array(
        'save' =>
        array(
            'desc' => $this->l('Save'),
            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
            '&token='.Tools::getAdminTokenLite('AdminModules'),
        ),
        'back' => array(
            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
            'desc' => $this->l('Back to list')
        )
    );
     
    /*Load current value*/    
	
    
	$helper->fields_value['id_group'] =Configuration::get('id_group')? Configuration::get('id_group'):Tools::getValue('id_group');
	$helper->fields_value['max_order_amount'] =Tools::getValue('max_order_amount',Configuration::get('MAX_ORDER_AMOUNT'));
	$helper->fields_value['min_order_period'] =Tools::getValue('min_order_period',Configuration::get('MIN_ORDER_PERIODE'));
	
	
	
	
     
    return $helper->generateForm($fields_form);
	
	
    }    
   
   
  
    	
	 public function addCustomerVIPGroup(){	
	 
	    $id_customer=(int)($this->context->customer->logged ? $this->context->customer->id: false);
	    $id_group=(int)$this->context->customer->id_default_group;
	   
	   
	   $CustomerVIPGroupObj=CustomerVIPGroup::loadByIdCustomer($id_customer);
	     	
        $CustomerVIPGroupObj->id_group=$id_group;				
		$CustomerVIPGroupObj->id_customer=$id_customer;
		
	   
        if(isset($CustomerVIPGroupObj) && !empty($CustomerVIPGroupObj->id) ){       	 
		
		$CustomerVIPGroupObj->update(); 
       
		
        }  
		
		else{
			
			$CustomerVIPGroupObj->add(); 
		}
	   
	  
	  
   }
     

   
   public function hookOrderConfirmation($params)
    {
         
        $id_customer=(int)($this->context->customer->logged ? $this->context->customer->id: false);
		
		$id_vip=(int)Configuration::get('ID_VIP_GROUP');
		$max_order_amount=Configuration::get('MAX_ORDER_AMOUNT');
		$total_paid_tax_incl=$this->getTotalPaid($params);
		
		if(isset($max_order_amount) && $total_paid_tax_incl>=$max_order_amount){
		  
		  $this->updateUser($id_vip);  
		  
		  $this->addCustomerVIPGroup();
		
		}
		 
    }
	
	
	
	 public  function updateUser($id_vip)
    {
         
		$id_customer=(int)($this->context->customer->logged ? $this->context->customer->id: false);
		  
		 
		 
		 Db::getInstance(_PS_USE_SQL_SLAVE_)->execute('
                UPDATE
                `'._DB_PREFIX_.'customer`  SET  `id_default_group`='.(int)$id_vip.' 
                 WHERE `id_customer` = '.(int)$id_customer
				 	   
                
				);
				
		
    }		
	
	
	
	
	public function getTotalPaid($params)
    {
		
		$id_customer=(int)($this->context->customer->logged ? $this->context->customer->id: false);		
		$total_paid_tax_incl=0;		
		$customerOrders =Order::getCustomerOrders($id_customer);
		
		//date_add
		$my_time=null;
		
		foreach($customerOrders as $customer_order) {	
          $my_time=strtotime($customer_order['date_add']);	
          if($my_time>=$this->getPeriod()){		  
	       $total_paid_tax_incl+=$customer_order['total_paid_tax_incl'];
		  }
		}	
		
		return  $total_paid_tax_incl;
		
	 
	}
	
	
	
	public  function getPeriod(){
		
		$min_order_period=Configuration::get('MIN_ORDER_PERIODE') ? Configuration::get('MIN_ORDER_PERIODE'):12;
		
		$one_day=24*3600;
		$one_month=$one_day*30;
		$one_year=$one_month*$min_order_period;
		
		
		return $one_year;
		
		
	}
   
   
  
  }

